#Basic-Banking-Android-App

This app is made to complete #Task2 of Graduate Rotational Internship Program(GRIP) of The Sparks Foundation i.e.Basic Banking System Android App.

Users can view bank details,transfer money and view transactions history.

